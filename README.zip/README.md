# Cargo24Express (Astro + Tailwind + i18n)

- `npm i`
- `npm run dev`
